# To use run the following from your system replacing the access and secret with your own
export AWS_ACCESS_KEY=AKIAHFHAS3FSJ
export AWS_SECRET_KEY=5NOPENOPENOPEI6wF
