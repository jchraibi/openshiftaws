#!/bin/bash

yum -y update
yum -y install kubernetes docker flannel etcd git vim
